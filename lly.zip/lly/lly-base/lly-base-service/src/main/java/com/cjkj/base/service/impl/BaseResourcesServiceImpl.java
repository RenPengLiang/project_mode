package com.cjkj.base.service.impl;

import com.cjkj.common.service.impl.SuperServiceImpl;
import com.cjkj.base.dao.BaseResourcesDao;
import com.cjkj.base.entity.BaseResources;
import com.cjkj.base.service.BaseResourcesService;
import org.springframework.stereotype.Service;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
@Service
public class BaseResourcesServiceImpl extends SuperServiceImpl<BaseResourcesDao,BaseResources> implements BaseResourcesService {

}