package com.cjkj.base.convert;

import com.cjkj.base.dto.req.add.EnterpriseInfoAddReq;
import com.cjkj.base.dto.req.edit.EnterpriseInfoEditReq;
import com.cjkj.base.dto.res.list.EnterpriseInfoRes;
import com.cjkj.base.entity.EnterpriseInfo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper
public interface EnterpriseInfoMapper {

    EnterpriseInfoMapper INSTANCE = Mappers.getMapper(EnterpriseInfoMapper.class);

    /**
     *  企业（维修厂）：基础数据添加参数转换
     * @param enterpriseInfoAddReq
     * @return
     */
    @Mappings({@Mapping(source = "operUserId",target="createdBy")
            ,@Mapping(source = "operUserName",target="createdByName")
            ,@Mapping(source = "operUserId",target="updatedBy")
            ,@Mapping(source = "operUserName",target="updatedByName")
            ,@Mapping(source = "city",target="city")})
    EnterpriseInfo addReqToBasic(EnterpriseInfoAddReq enterpriseInfoAddReq);

    /**
     *  企业（维修厂）：基础数据更新
     * @param enterpriseInfoEditReq
     * @return
     */
    @Mappings({@Mapping(source = "operUserId",target="createdBy")
            ,@Mapping(source = "operUserName",target="createdByName")
            ,@Mapping(source = "operUserId",target="updatedBy")
            ,@Mapping(source = "operUserName",target="updatedByName")})
    EnterpriseInfo updateReqToBasic(EnterpriseInfoEditReq enterpriseInfoEditReq);

    EnterpriseInfoRes basicToRes(EnterpriseInfo enterpriseInfo);
}
