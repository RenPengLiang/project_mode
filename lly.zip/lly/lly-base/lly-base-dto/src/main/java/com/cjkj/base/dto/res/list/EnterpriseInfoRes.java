package com.cjkj.base.dto.res.list;

import com.cjkj.base.dto.res.BaseRes;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
@Data
@ApiModel("企业信息->返回")
public class EnterpriseInfoRes extends BaseRes {
    private static final long serialVersionUID = 1L;
    /**
     * 主键
     */
    @ApiModelProperty("主键")
    private String id;

    /**
     * 企业ID
     */
    @ApiModelProperty("企业ID(关联架构)")
    private String departmentId;

    /**
     * 名称
     */
    @ApiModelProperty("名称")
    private String name;

    /**
     * 企业类型（1：维修厂，2：承运商）
     */
    @ApiModelProperty("企业类型（1：维修厂，2：承运商）")
    private String enterpriseType;

    /**
     * 联系人
     */
    @ApiModelProperty("联系人")
    private String contacts;

    /**
     * 联系电话
     */
    @ApiModelProperty("联系电话")
    private String contactsTel;

    /**
     * 法人
     */
    @ApiModelProperty("法人")
    private String legalPerson;

    /**
     * 营业执照号
     */
    @ApiModelProperty("营业执照号")
    private String businessLicense;

    /**
     * 省
     */
    @ApiModelProperty("省")
    private String province;

    /**
     * 省
     */
    @ApiModelProperty("省名称")
    private String provinceName;


    /**
     * 市
     */
    @ApiModelProperty("市")
    private String city;

    /**
     * 市
     */
    @ApiModelProperty("市名称")
    private String cityName;

    /**
     * 县
     */
    @ApiModelProperty("县")
    private String county;

    /**
     * 详细地址
     */
    @ApiModelProperty("详细地址")
    private String address;

    /**
     * 经度
     */
    @ApiModelProperty("经度")
    private BigDecimal lng;

    /**
     * 纬度
     */
    @ApiModelProperty("纬度")
    private BigDecimal lat;

    /**
     * 是否有效
     */
    @ApiModelProperty("是否有效")
    private String effective;

    /**
     * 开户行
     */
    @ApiModelProperty("开户行")
    private String bank;

    /**
     * 开户行账号
     */
    @ApiModelProperty("开户行账号")
    private String bankNo;
}