package com.cjkj.base.config;

import com.cjkj.common.config.DefaultMybatisPlusConfig;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description: 
 */
@Configuration
@MapperScan({"com.cjkj.mobile.dao*"})
public class MybatisPlusConfig extends DefaultMybatisPlusConfig {
}
