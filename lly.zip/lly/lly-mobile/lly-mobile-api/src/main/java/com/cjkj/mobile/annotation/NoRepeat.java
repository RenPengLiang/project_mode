package com.cjkj.mobile.annotation;

import java.lang.annotation.*;


/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface NoRepeat {
    /**
     * 时长
     * @return
     */
    long longTime() default 3000L;

    /**
     * 检查入参
     * @return
     */
    boolean checkBody() default false;
}
