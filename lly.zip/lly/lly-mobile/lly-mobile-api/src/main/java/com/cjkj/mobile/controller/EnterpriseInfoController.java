package com.cjkj.mobile.controller;

import com.cjkj.mobile.convert.EnterpriseInfoMapper;
import com.cjkj.mobile.dto.req.BaseIds;
import com.cjkj.mobile.dto.req.add.EnterpriseInfoAddReq;
import com.cjkj.mobile.dto.req.edit.EnterpriseInfoEditReq;
import com.cjkj.mobile.dto.req.list.EnterpriseInfoListReq;
import com.cjkj.mobile.dto.res.list.EnterpriseInfoRes;
import com.cjkj.mobile.entity.EnterpriseInfo;
import com.cjkj.mobile.service.EnterpriseInfoService;
import com.cjkj.common.model.PageData;
import com.cjkj.common.model.ResultData;
import com.cjkj.mobile.annotation.NoRepeat;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import java.util.Arrays;
import java.util.List;


/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description: 企业表
 */
@RestController
@RequestMapping("enterprise")
@Api(value = "EnterpriseInfoController", tags = "企业信息")
public class EnterpriseInfoController {
    @Autowired
    private EnterpriseInfoService enterpriseInfoService;

    /**
     * 列表
     */
    @PostMapping("/list")
    @ApiOperation(value = "企业信息->查询操作", notes = "\t参数为对象json数据")
    public ResultData<PageData<EnterpriseInfoRes>> list(@RequestBody EnterpriseInfoListReq enterpriseInfoListReq){
        return ResultData.ok(enterpriseInfoService.listPage(enterpriseInfoListReq));
    }


    /**
     * 导出
     */
    @PostMapping("/export")
    @ApiOperation(value = "导出-企业信息->查询操作", notes = "\t参数为对象json数据")
    public ResultData<List<EnterpriseInfoRes>> export(@RequestBody  EnterpriseInfoListReq enterpriseInfoListReq){
        return ResultData.ok(enterpriseInfoService.listExport(enterpriseInfoListReq));
    }

    /**
     * 信息
     */
    @GetMapping("/get/{id}")
    @ApiOperation(value = "企业信息->获取详细信息", notes = "\t参数为对象json数据")
    public ResultData<EnterpriseInfoRes> info(@PathVariable("id") String id){
        if(StringUtils.isEmpty(id)){
            return ResultData.failed("id必传！");
        }
        EnterpriseInfo enterpriseInfo = enterpriseInfoService.getById(id);
        return ResultData.ok(EnterpriseInfoMapper.INSTANCE.basicToRes(enterpriseInfo));
    }

    /**
     * 保存
     */
    @PostMapping("/save")
    @ApiOperation(value = "企业信息->新增", notes = "\t参数为对象json数据")
    @NoRepeat(longTime = 1000L,checkBody = true)
    public ResultData save(@RequestBody @Validated EnterpriseInfoAddReq enterpriseInfoAddReq){
        if(enterpriseInfoService.insert(enterpriseInfoAddReq)){
            return ResultData.ok();
        }
        return ResultData.failed("添加失败！");
    }

    /**
     * 修改
     */
    @PostMapping("/update")
    @ApiOperation(value = "企业信息->修改", notes = "\t参数为对象json数据")
    public ResultData update(@RequestBody @Validated EnterpriseInfoEditReq enterpriseInfoEditReq){
        if(enterpriseInfoService.updateEnterpriseInfo(enterpriseInfoEditReq)){
            return ResultData.ok();
        }
        return ResultData.failed("修改失败！");
    }

    /**
     * 删除
     */
    @PostMapping("/delete")
    @ApiOperation(value = "企业信息->删除", notes = "\t参数为对象json数据")
    public ResultData delete(@RequestBody BaseIds baseIds){
        if(enterpriseInfoService.delete(Arrays.asList(baseIds.getIds()))){
            return ResultData.ok();
        }
        return ResultData.failed("删除失败!");
    }

}
