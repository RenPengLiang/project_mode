package com.cjkj.mobile.config;

import com.cjkj.common.config.DateMetaObjectHandler;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
@Configuration
@Primary
public class MyDateMetaObjectHandler extends DateMetaObjectHandler {

}
