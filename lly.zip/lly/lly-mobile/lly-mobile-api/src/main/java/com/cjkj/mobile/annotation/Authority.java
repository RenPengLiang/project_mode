package com.cjkj.mobile.annotation;

import java.lang.annotation.*;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Authority {

    /**
     * 角色ID
     * @return
     */
    String roleIdField() default "roleId";

    boolean queryDepartmentTopId() default false;

    boolean queryDepartmentIdList() default true;

}
