package com.cjkj.mobile.dao;

import com.cjkj.mobile.entity.EnterpriseInfo;
import com.cjkj.common.mapper.SuperMapper;
import org.springframework.stereotype.Repository;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
@Repository
public interface EnterpriseInfoDao extends SuperMapper<EnterpriseInfo> {
}