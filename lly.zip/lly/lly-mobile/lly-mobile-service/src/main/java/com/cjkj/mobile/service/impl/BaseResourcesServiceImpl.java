package com.cjkj.mobile.service.impl;

import com.cjkj.common.service.impl.SuperServiceImpl;
import com.cjkj.mobile.dao.BaseResourcesDao;
import com.cjkj.mobile.entity.BaseResources;
import com.cjkj.mobile.service.BaseResourcesService;
import org.springframework.stereotype.Service;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
@Service
public class BaseResourcesServiceImpl extends SuperServiceImpl<BaseResourcesDao,BaseResources> implements BaseResourcesService {

}