```
lly -- 连连运2.0
│  ├─lly-base -- 基础数据
│  │  ├─lly-base-dto -- 对外提供接口模块启动器，提供各类启动配置和 `Controller`
│  │  ├─lly-base-service -- 服务层，包含 Service Entity Mapper 等
│  │  ├─lly-base-api -- 接口
│  ├─lly-excel -- excel导入导出服务
│  ├─lly-mobile -- app端
│  │  ├─lly-mobile-dto -- 对外提供接口模块启动器，提供各类启动配置和 `Controller`
│  │  ├─lly-mobile-service -- 服务层，包含 Service Entity Mapper 等
│  │  ├─lly-mobile-api -- 接口
│  ├─lly-web -- web端
│  │  ├─lly-web-dto -- 对外提供接口模块启动器，提供各类启动配置和 `Controller`
│  │  ├─lly-web-service -- 服务层，包含 Service Entity Mapper 等
│  │  ├─lly-web-api -- 接口
│  ├─lly-pay -- 支付模块
│  │  ├─lly-pay-dto -- 对外提供接口模块启动器，提供各类启动配置和 `Controller`
│  │  ├─lly-pay-service -- 服务层，包含 Service Entity Mapper 等
│  │  ├─lly-pay-api -- 接口
项目刨析
1.maven构建+springboot+mybatisplus+mysql搭建项目
2.配置中心实现统一配置信息配置
3.使用分布式事务seata进行事务管理
4.使用sentinel实现服务熔断，限流，链路管理
5.使用nacos做服务注册中心
6.使用redis做系统缓存
7.使用rabbitmq做消息中间件
```


