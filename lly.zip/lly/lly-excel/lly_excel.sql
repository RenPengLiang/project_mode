/*
 Navicat Premium Data Transfer

 Source Server         : 连连运系统重构数据库
 Source Server Type    : MySQL
 Source Server Version : 50732
 Source Host           : 10.253.96.110:3306
 Source Schema         : lly_excel

 Target Server Type    : MySQL
 Target Server Version : 50732
 File Encoding         : 65001

 Date: 14/12/2020 15:16:07
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for export_config
-- ----------------------------
DROP TABLE IF EXISTS `export_config`;
CREATE TABLE `export_config`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `export_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '导出配置表主键',
  `field_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '参数字段名',
  `excel_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Excel字段名',
  `created_by` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '创建人',
  `created_by_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '更新人',
  `updated_by_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '更新人名称',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 377 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '导出字段配置 ' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of export_config
-- ----------------------------
INSERT INTO `export_config` VALUES (5, 'receive_settlement_export', 'serialNumber', '结算流水号', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (350, 'receive_settlement_export', 'totalReceivableFee', '应收运费(元)', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (351, 'receive_settlement_export', 'couponOffsetFee', '优惠券抵扣金额(元)', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (352, 'receive_settlement_export', 'totalInvoiceFee', '开票金额(元)', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (353, 'receive_settlement_export', 'differenceFee', '差额(元)', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (354, 'receive_settlement_export', 'customerName', '客户名称', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (355, 'receive_settlement_export', 'taxCode', '纳税人识别号', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (356, 'receive_settlement_export', 'phone', '公司电话', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (357, 'receive_settlement_export', 'invoiceAddress', '公司地址', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (358, 'receive_settlement_export', 'bankName', '开户银行名称', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (359, 'receive_settlement_export', 'bankAccount', '开户行账号', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (360, 'receive_settlement_export', 'invoiceTypeStr', '发票类型', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (361, 'receive_settlement_export', 'pickupPerson', '收件人', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (362, 'receive_settlement_export', 'pickupPhone', '收件人电话', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (363, 'receive_settlement_export', 'pickupAddress', '收件地址', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (364, 'receive_settlement_export', 'startAddress', '始发地', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (365, 'receive_settlement_export', 'endAddress', '目的地', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (366, 'receive_settlement_export', 'remark', '备注', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (367, 'receive_settlement_export', 'invoiceNo', '发票号', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (369, 'receive_settlement_export', 'applyTimeStr', '申请结算时间', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (371, 'receive_settlement_export', 'applicantName', '申请人', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (373, 'receive_settlement_export', 'confirmTimeStr', '确认开票时间', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (374, 'receive_settlement_export', 'confirmName', '确认人', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (375, 'receive_settlement_export', 'verificationTimeStr', '核销时间', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `export_config` VALUES (376, 'receive_settlement_export', 'verificationName', '核销人', NULL, NULL, NULL, NULL, NULL, NULL);

-- ----------------------------
-- Table structure for export_info
-- ----------------------------
DROP TABLE IF EXISTS `export_info`;
CREATE TABLE `export_info`  (
  `id` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '主键',
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '名称',
  `service_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '服务名称',
  `service_path` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '服务访问地址',
  `created_by` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '创建人',
  `created_by_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '更新人',
  `updated_by_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '更新人名称',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `api_key` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT 'apiKey用于文件名称加前缀【系统名称】来区分同一个文件夹下不同的文件'
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '导出配置' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of export_info
-- ----------------------------
INSERT INTO `export_info` VALUES ('receive_settlement_export', '已收款(账期)列表导出', 'cjyc-web-api', '/cjyc/web/finance/listExcelReceiveSettlementPayed', NULL, NULL, NULL, NULL, NULL, NULL, '044843d5011b4781b7ff6cfbf10727ed');

-- ----------------------------
-- Table structure for file_down_log
-- ----------------------------
DROP TABLE IF EXISTS `file_down_log`;
CREATE TABLE `file_down_log`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `file_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '文件名称',
  `create_time` bigint(20) NULL DEFAULT NULL COMMENT '创建时间',
  `state` int(2) NULL DEFAULT NULL COMMENT '状态：1：成功 2：失败',
  `file_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '文件所在路径',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of file_down_log
-- ----------------------------
INSERT INTO `file_down_log` VALUES (2, '已收款(账期)列表导出2020101509330159.xlsx', 1602725582044, 1, 'https://cjwl-test-bucket.obs.cn-north-1.myhuaweicloud.com:443/%E9%9F%B5%E8%BD%A62.0Web%E7%AB%AF%2F%E5%B7%B2%E6%94%B6%E6%AC%BE%28%E8%B4%A6%E6%9C%9F%29%E5%88%97%E8%A1%A8%E5%AF%BC%E5%87%BA2020101509330159.xlsx');

-- ----------------------------
-- Table structure for import_config
-- ----------------------------
DROP TABLE IF EXISTS `import_config`;
CREATE TABLE `import_config`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `import_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '导入配置表主键',
  `field_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '参数字段名',
  `excel_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Excel字段名',
  `sub_field` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '是否子字段',
  `group_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '分组ID',
  `required` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '是否必填',
  `field_type` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '字段类型（1：整数，2：小数，3：字符串，4：日期，5：日期时间）',
  `created_by` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '创建人',
  `created_by_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '更新人',
  `updated_by_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '更新人名称',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 27 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '导入字段配置 ' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for import_info
-- ----------------------------
DROP TABLE IF EXISTS `import_info`;
CREATE TABLE `import_info`  (
  `id` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '主键',
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '名称',
  `template_url` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '模板路径',
  `service_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '服务名称',
  `service_path` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '服务访问地址',
  `created_by` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '创建人',
  `created_by_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '更新人',
  `updated_by_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '更新人名称',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间'
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '导入配置' ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
