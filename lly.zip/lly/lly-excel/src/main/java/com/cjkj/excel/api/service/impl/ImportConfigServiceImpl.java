package com.cjkj.excel.api.service.impl;

import com.cjkj.common.service.impl.SuperServiceImpl;
import com.cjkj.excel.api.dao.ImportConfigDao;
import com.cjkj.excel.api.entity.ImportConfig;
import com.cjkj.excel.api.service.ImportConfigService;
import org.springframework.stereotype.Service;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @Description:
 */
@Service
public class ImportConfigServiceImpl extends SuperServiceImpl<ImportConfigDao, ImportConfig> implements ImportConfigService {

}
