package com.cjkj.excel.api.service;

import com.alibaba.fastjson.JSONObject;
import com.cjkj.excel.api.vo.ExportRes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @Description:
 */
public interface ExportAsyncService {
    /**
     * 异步执行
     *
     * @param exportRes
     * @param jsonObject
     */
    void executeAsync(ExportRes exportRes, JSONObject jsonObject, HttpServletRequest request);

    /**
     * 执行
     *
     * @param taskId
     * @param jsonObject
     * @param response
     */
    void excute(String taskId, JSONObject jsonObject, HttpServletResponse response, HttpServletRequest request);
}
