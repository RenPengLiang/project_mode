package com.cjkj.excel.api.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @Description: 导入字段配置
 */
@Data
@TableName("import_config")
public class ImportConfig implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @TableId
    private String id;
    /**
     * 导入配置表主键
     */
    private String importId;
    /**
     * 参数字段名
     */
    private String fieldName;
    /**
     * Excel字段名
     */
    private String excelName;
    /**
     * 是否子字段
     */
    private String subField;
    /**
     * 分组ID
     */
    private String groupId;
    /**
     * 是否必填
     */
    private String required;
    /**
     * 字段类型（1：整数，2：小数，3：字符串，4：日期，5：日期时间）
     */
    private String fieldType;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 创建人名称
     */
    private String createdByName;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 更新人
     */
    private String updatedBy;
    /**
     * 更新人名称
     */
    private String updatedByName;
    /**
     * 更新时间
     */
    private Date updateTime;

}
