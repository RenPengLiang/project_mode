package com.cjkj.excel.api.service;

import com.cjkj.common.service.ISuperService;
import com.cjkj.excel.api.entity.ExportConfig;

import java.util.List;

/**
 * 导出字段配置
 *
 * @author: RenPL
 * @date: 2020/9/24 16:24
 */
public interface ExportConfigService extends ISuperService<ExportConfig> {
    /**
     * 通过ID查询配置列表
     *
     * @param exportId
     * @return
     */
    List<ExportConfig> queryByExportId(String exportId);
}

