package com.cjkj.excel.api;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * @author renpl
 */
@SpringBootApplication
@EnableDiscoveryClient
@MapperScan("com.cjkj.excel.api.dao")
@EnableAsync
public class ExcelApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExcelApiApplication.class, args);
    }

}
