package com.cjkj.excel.api.dao;

import com.cjkj.common.mapper.SuperMapper;
import com.cjkj.excel.api.entity.ExportInfo;
import org.springframework.stereotype.Repository;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @description: 导出配置
 */
@Repository
public interface ExportInfoDao extends SuperMapper<ExportInfo> {

}
