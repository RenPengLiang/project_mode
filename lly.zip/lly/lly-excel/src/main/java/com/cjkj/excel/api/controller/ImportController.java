package com.cjkj.excel.api.controller;

import com.alibaba.fastjson.JSONObject;
import com.cjkj.common.model.ResultData;
import com.cjkj.excel.api.vo.ImportRes;
import com.cjkj.excel.api.service.ImportService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @description: excel导入管理类
 */
@RestController
@RequestMapping("import")
@Api(value = "ImportController", tags = "导入")
public class ImportController {
    @Resource
    ImportService importService;

    /**
     * 导入
     *
     * @return
     */
    @PostMapping("/excel")
    @ApiOperation(value = "导入")
    public JSONObject importExcel(HttpServletRequest request, @RequestParam("file") MultipartFile file, @RequestParam("importId") String importId) {
        return importService.importExcel(request, file, importId);
    }

    /**
     * 列表
     *
     * @return
     */
    @GetMapping("/get/{importId}")
    @ApiOperation(value = "获取模板")
    public ResultData<ImportRes> importExcel(@PathVariable("importId") String importId) {
        return ResultData.ok(importService.get(importId));
    }
}
