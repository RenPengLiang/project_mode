package com.cjkj.excel.api.service;

import com.cjkj.common.service.ISuperService;
import com.cjkj.excel.api.entity.ImportInfo;

/**
 * 导入配置
 *
 * @author: RenPL
 * @date: 2020/9/24 16:24
 */
public interface ImportInfoService extends ISuperService<ImportInfo> {

}

