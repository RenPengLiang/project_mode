package com.cjkj.excel.api.exception;

import com.cjkj.common.exception.GlobalExceptionAdvice;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * @className CommonExceptionHandler
 * @description 系统异常处理类，将系统异常统一格式化为系统JSON格式
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @version v1.0
 **/
@RestControllerAdvice
public class CommonExceptionHandler extends GlobalExceptionAdvice {
	
}
