package com.cjkj.excel.api.service;

import com.cjkj.common.service.ISuperService;
import com.cjkj.excel.api.entity.ImportConfig;

/**
 * 导入字段配置
 *
 * @author: RenPL
 * @date: 2020/9/24 16:24
 */
public interface ImportConfigService extends ISuperService<ImportConfig> {
}

