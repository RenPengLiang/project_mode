package com.cjkj.excel.api.controller;

import com.alibaba.fastjson.JSONObject;
import com.cjkj.common.model.ResultData;
import com.cjkj.excel.api.entity.FileDownLog;
import com.cjkj.excel.api.vo.ExportRes;
import com.cjkj.excel.api.service.ExportService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @description: excel导出管理类
 */
@RestController
@RequestMapping("export")
@Api(value = "ExportController", tags = "导出")
public class ExportController {
    @Resource
    ExportService exportService;

    /**
     * 列表
     */
    @PostMapping("/exportAsync")
    @ApiOperation(value = "导出通用模板(异步)")
    public ResultData<ExportRes> exportAsync(HttpServletRequest request, @RequestBody JSONObject jsonObject) {
        return ResultData.ok(exportService.exportAsync(jsonObject, request));
    }

    /**
     * 列表
     */
    @PostMapping("/exportSync")
    @ApiOperation(value = "导出通用模板(同步)")
    public void exportSync(HttpServletRequest request, HttpServletResponse response, @RequestBody JSONObject jsonObject) {
        exportService.export(jsonObject, response, request);
    }

    /**
     * 列表
     */
    @GetMapping("/getExportAsync/{id}")
    @ApiOperation(value = "获取导出进度")
    public ResultData<ExportRes> getExport(@PathVariable("id") String taskId) {
        return ResultData.ok(exportService.getExport(taskId));
    }

    /**
     * 列表
     */
    @GetMapping("/listFileDownLogInfo")
    @ApiOperation(value = "获取文件下载记录")
    public ResultData<List<FileDownLog>> listFileDownLogInfo() {
        return ResultData.ok(exportService.listFileDownLogInfo());
    }
}
