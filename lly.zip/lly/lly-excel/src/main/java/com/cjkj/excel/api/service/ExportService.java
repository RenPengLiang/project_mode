package com.cjkj.excel.api.service;

import com.alibaba.fastjson.JSONObject;
import com.cjkj.excel.api.entity.FileDownLog;
import com.cjkj.excel.api.vo.ExportRes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @Description:
 */
public interface ExportService {
    /**
     * 导出异步
     *
     * @param jsonObject
     * @return
     */
    ExportRes exportAsync(JSONObject jsonObject, HttpServletRequest request);

    /**
     * 导出
     *
     * @param jsonObject
     * @return
     */
    void export(JSONObject jsonObject, HttpServletResponse response, HttpServletRequest request);

    /**
     * 通过任务ID，获取执行进度
     *
     * @param taskId
     * @return
     */
    ExportRes getExport(String taskId);

    /**
     * 获取文件下载记录
     *
     * @return
     */
    List<FileDownLog> listFileDownLogInfo();
}
