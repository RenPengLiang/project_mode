package com.cjkj.excel.api.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @Description: 导出相关信息
 */
@Data
@ApiModel("导出相关信息")
public class ExportRes {
    /**
     * 配置ID
     */
    @ApiModelProperty(value = "配置ID", hidden = true)
    private String exportTaskId;
    /**
     * 任务ID
     */
    @ApiModelProperty("任务ID")
    private String taskId;
    /**
     * 文件名称
     */
    @ApiModelProperty("文件名称")
    private String name;
    /**
     * 百分比
     */
    @ApiModelProperty("百分比")
    private String percent;
    /**
     * 开始时间
     */
    @ApiModelProperty("开始时间")
    private String startTime;
    /**
     * 占用时长
     */
    @ApiModelProperty("占用时长")
    private String timeStr;
    /**
     * 结束时间
     */
    @ApiModelProperty("结束时间")
    private String endTime;
    /**
     * 下载地址
     */
    @ApiModelProperty("下载地址")
    private String url;

    /**
     * 文件大小
     */
    @ApiModelProperty("文件大小")
    private String fileSize;

    /**
     * 是否取消
     */
    @ApiModelProperty("是否取消")
    private Boolean isCancel;

    /**
     * 错误信息
     */
    @ApiModelProperty("错误信息")
    private String message;
}
