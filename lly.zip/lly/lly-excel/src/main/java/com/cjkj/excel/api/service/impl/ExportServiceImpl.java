package com.cjkj.excel.api.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cjkj.common.exception.BusinessException;
import com.cjkj.common.redis.template.StringRedisUtil;
import com.cjkj.common.utils.DateUtil;
import com.cjkj.excel.api.dao.FileDownLogDao;
import com.cjkj.excel.api.entity.FileDownLog;
import com.cjkj.excel.api.service.ExportAsyncService;
import com.cjkj.excel.api.service.ExportService;
import com.cjkj.excel.api.vo.ExportRes;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @Description:
 */
@Service
@Slf4j
public class ExportServiceImpl implements ExportService {
    @Resource
    StringRedisUtil stringRedisUtil;
    @Resource
    ExportAsyncService exportAsyncService;
    @Resource
    FileDownLogDao fileDownLogDao;

    private final String taskIdField = "exportTaskId";
    private final long daySeconds = 86400;

    @Override
    public ExportRes exportAsync(JSONObject jsonObject, HttpServletRequest request) {
        Object exportId = jsonObject.get(taskIdField);
        if (exportId == null) {
            throw new BusinessException("未找到导出ID");
        }
        String taskId = UUID.randomUUID().toString().replaceAll("-", "");
        String startTime = DateUtil.format(new Date(), "yyyy-MM-dd HH:mm:ss");
        ExportRes exportRes = new ExportRes();
        exportRes.setTaskId(taskId);
        exportRes.setStartTime(startTime);
        exportRes.setPercent("0");
        exportRes.setExportTaskId(exportId.toString());
        stringRedisUtil.set(taskIdField + ":" + taskId, JSONObject.toJSONString(exportRes), daySeconds);
        exportAsyncService.executeAsync(exportRes, jsonObject, request);
        return exportRes;
    }

    @Override
    public void export(JSONObject jsonObject, HttpServletResponse response, HttpServletRequest request) {
        Object exportId = jsonObject.get(taskIdField);
        if (exportId == null) {
            throw new BusinessException("未找到导出ID");
        }
        exportAsyncService.excute(exportId.toString(), jsonObject, response, request);
    }

    @Override
    public ExportRes getExport(String taskId) {
        String json = stringRedisUtil.getStrValue(taskIdField + ":" + taskId);
        return JSONObject.parseObject(json, ExportRes.class);
    }

    @Override
    public List<FileDownLog> listFileDownLogInfo() {
        return fileDownLogDao.selectList(new QueryWrapper<>());
    }
}
