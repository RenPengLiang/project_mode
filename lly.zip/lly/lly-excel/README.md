# 公共excel项目
## 导出使用步骤
* 前端调用异步excel导出步骤
    * 用户点击下载按钮调用接口：/export/exportAsync 		
    * 前端进度条获取进度调用接口：/export/getExportAsync 		
    * 前端提供一个下载标识比如：向下的下载箭头
    * 点击这个箭头弹出一个页面，页面列表数据调用接口：/export/listFileDownLogInfo 
    * 页面列表字段有：创建时间，文件名称，状态，操作【列表状态是成功时显示下载按钮】
    * 点击下载按钮通过文件url【file_path】下载文件
    
* 前端调用同步excel导出步骤
    * 用户点击下载按钮调用接口：/export/exportSync 	
    
## 导入使用步骤	
