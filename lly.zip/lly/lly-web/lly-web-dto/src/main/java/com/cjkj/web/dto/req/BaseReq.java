package com.cjkj.web.dto.req;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
@Data
public class BaseReq {
    /**
     * 用户ID
     */
    @ApiModelProperty(value="操作用户ID",hidden = true)
    private String operUserId;
    /**
     * 用户名称
     */
    @ApiModelProperty(value="操作用户名称",hidden = true)
    private String operUserName;
    /**
     * 操作人企业ID
     */
    @ApiModelProperty(value="操作人企业ID",hidden = true)
    private String operDepartmentTopId;
    /**
     * 操作人企业名称
     */
    @ApiModelProperty(value="操作人企业名称",hidden = true)
    private String operDepartmentTopName;

    /**
     * 操作人机构ID
     */
    @ApiModelProperty(value="操作人机构ID",hidden = true)
    private String operDepartmentId;
    /**
     * 操作人机构名称
     */
    @ApiModelProperty(value="操作人机构名称",hidden = true)
    private String operDepartmentName;
}
