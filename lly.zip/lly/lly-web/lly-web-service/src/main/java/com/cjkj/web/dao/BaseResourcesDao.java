package com.cjkj.web.dao;

import com.cjkj.web.entity.BaseResources;
import com.cjkj.common.mapper.SuperMapper;
import org.springframework.stereotype.Repository;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
@Repository
public interface BaseResourcesDao extends SuperMapper<BaseResources> {

}