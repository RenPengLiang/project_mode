package com.cjkj.web.service;


import com.cjkj.web.dto.req.add.EnterpriseInfoAddReq;
import com.cjkj.web.dto.req.edit.EnterpriseInfoEditReq;
import com.cjkj.web.dto.req.list.EnterpriseInfoListReq;
import com.cjkj.web.dto.res.list.EnterpriseInfoRes;
import com.cjkj.web.entity.EnterpriseInfo;
import com.cjkj.common.model.PageData;
import com.cjkj.common.service.ISuperService;

import java.util.List;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
public interface EnterpriseInfoService extends ISuperService<EnterpriseInfo> {
    /**
     * 添加企业（维修厂）
     * @param enterpriseInfoAddReq
     * @return
     */
    boolean insert(EnterpriseInfoAddReq enterpriseInfoAddReq);

    /**
     * 更新维修厂
     * @param enterpriseInfoEditReq
     * @return
     */
    boolean updateEnterpriseInfo(EnterpriseInfoEditReq enterpriseInfoEditReq);

    PageData<EnterpriseInfoRes> listPage(EnterpriseInfoListReq enterpriseInfoListReq);

    boolean delete(List<String> asList);

    List<EnterpriseInfoRes> listExport(EnterpriseInfoListReq enterpriseInfoListReq);
}