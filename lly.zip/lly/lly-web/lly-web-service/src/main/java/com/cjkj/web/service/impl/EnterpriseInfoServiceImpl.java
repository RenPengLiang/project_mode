package com.cjkj.web.service.impl;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cjkj.web.dao.EnterpriseInfoDao;
import com.cjkj.web.dto.req.add.EnterpriseInfoAddReq;
import com.cjkj.web.dto.req.edit.EnterpriseInfoEditReq;
import com.cjkj.common.exception.BusinessException;
import com.cjkj.common.model.PageData;
import com.cjkj.common.service.impl.SuperServiceImpl;
import com.cjkj.web.convert.EnterpriseInfoMapper;
import com.cjkj.web.dto.req.list.EnterpriseInfoListReq;
import com.cjkj.web.dto.res.list.EnterpriseInfoRes;
import com.cjkj.web.entity.EnterpriseInfo;
import com.cjkj.web.service.EnterpriseInfoService;
import com.cjkj.web.util.BaseUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
@Service
public class EnterpriseInfoServiceImpl extends SuperServiceImpl<EnterpriseInfoDao,EnterpriseInfo> implements EnterpriseInfoService {

    /**
     * 新增维修厂：
     * 1、先判断是否已经存在该维修厂
     * 2、不存在，则调用架构接口，获取维修厂和维修厂id
     * 3、添加到数据库
     * @param enterpriseInfoAddReq
     * @return
     */
    @Override
    public boolean insert(EnterpriseInfoAddReq enterpriseInfoAddReq) {
        EnterpriseInfo enterpriseInfo = super.getOne(new QueryWrapper<EnterpriseInfo>().lambda().select(EnterpriseInfo::getDepartmentId)
                .eq(EnterpriseInfo::getName,enterpriseInfoAddReq.getName()));
        if(enterpriseInfo!=null){
            throw new BusinessException("添加失败，该维修厂已经存在！");
        }
        enterpriseInfo = EnterpriseInfoMapper.INSTANCE.addReqToBasic(enterpriseInfoAddReq);
        return super.save(enterpriseInfo);

    }

    @Override
    public boolean updateEnterpriseInfo(EnterpriseInfoEditReq enterpriseInfoEditReq) {
        EnterpriseInfo enterpriseInfo = EnterpriseInfoMapper.INSTANCE.updateReqToBasic(enterpriseInfoEditReq);
        return super.updateById(enterpriseInfo);
    }

    /**
     * 分页查询
     * @param enterpriseInfoListReq
     * @return
     */
    @Override
    public PageData<EnterpriseInfoRes> listPage(EnterpriseInfoListReq enterpriseInfoListReq) {
        Page<EnterpriseInfo> page=new Page<EnterpriseInfo>();
        page.setSize(enterpriseInfoListReq.getPageSize());
        page.setCurrent(enterpriseInfoListReq.getPageNum());
        PageData<EnterpriseInfo> page1 = super.getPage(page, getListParam(enterpriseInfoListReq));
        List<EnterpriseInfo> list = page1.getList();
        List<EnterpriseInfoRes> collect = baseListToDto(list);
        return new PageData<EnterpriseInfoRes>(page1.getTotal(),collect);
    }

    /**
     * base转换为dto
     * @param list
     * @return
     */
    private List<EnterpriseInfoRes> baseListToDto(List<EnterpriseInfo> list) {
        return list.stream().map(x -> {
            EnterpriseInfoRes enterpriseInfoRes = new EnterpriseInfoRes();
            BeanUtils.copyProperties(x, enterpriseInfoRes);
            enterpriseInfoRes.setBankNo(BaseUtil.hiddenStr(x.getBankNo()));
            return enterpriseInfoRes;
        }).collect(Collectors.toList());
    }

    /**
     * 1、维修厂还有未结算完成的单据，有，则不删除
     * @param idList
     * @return
     */
    @Override
    public boolean delete(List<String> idList) {
        /**
         * 1、需要去调用亮总接口，看看是否允许删除
         */
        Collection<EnterpriseInfo> enterpriseInfos = super.listByIds(idList);
        if(CollectionUtils.isEmpty(enterpriseInfos)){
            throw new BusinessException("该数据不存在！");
        }
        //删除数据
        return super.removeByIds(idList);
    }

    /**
     * 导出
     * @param enterpriseInfoListReq
     * @return
     */
    @Override
    public List<EnterpriseInfoRes> listExport(EnterpriseInfoListReq enterpriseInfoListReq) {
        List<EnterpriseInfo> list = super.list(getListParam(enterpriseInfoListReq));
        return baseListToDto(list);
    }

    /**
     * 分页查询和list查询参数
     * @param enterpriseInfoListReq
     * @return
     */
    private LambdaQueryWrapper<EnterpriseInfo> getListParam(EnterpriseInfoListReq enterpriseInfoListReq) {
        return new QueryWrapper<EnterpriseInfo>().lambda()
                .eq(!StringUtils.isEmpty(enterpriseInfoListReq.getEffective()), EnterpriseInfo::getEffective, enterpriseInfoListReq.getEffective())
                .eq(!StringUtils.isEmpty(enterpriseInfoListReq.getName()), EnterpriseInfo::getName, enterpriseInfoListReq.getName())
                .orderByDesc(EnterpriseInfo::getCreateTime);
    }
}