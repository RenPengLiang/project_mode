package com.cjkj.pay.dto.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
@Data
@ApiModel("删除参数")
public class BaseIds {
    @ApiModelProperty("主键")
    @NotBlank(message = "ids数组必传")
    private String[] ids;
}
