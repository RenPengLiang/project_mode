package com.cjkj.pay.util;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description: 公共方法
 */
public class BaseUtil {

    /**
     * 隐藏中间4位
     * @param target 需要隐藏的字符串 长度必须大于等于11
     * @return
     */
    public static String hiddenStr(String target){
        if(target.length()<11){
            return target;
        }
        String replace = target.substring(4, target.length()-4);
        return target.replace(replace, "****");
    }

    /**
     * 判断进行in操作还是like操作，得结合业务
     * @param paramName
     * @return
     */
    public static List inOrLike(String paramName){
        List list=null;
        if(org.apache.commons.lang3.StringUtils.isNotBlank(paramName)){
            //替换中午“，”,空格
            String replace = paramName.trim().replace("，", ",");
            if(replace.contains(",")){
                String[] plateNos = replace.split(",");
                list = Arrays.asList(plateNos);
            }
        }
        return list;
    }

    /**
     * 分割list
     * @param list
     * @param groupSize
     * @return
     */
    public static <T>List<List<T>> splitList(List<T> list , int groupSize){
        int length = list.size();
        // 计算可以分成多少组
        int num = ( length + groupSize - 1 )/groupSize ; // TODO
        List<List<T>> newList = new ArrayList<>(num);
        for (int i = 0; i < num; i++) {
            // 开始位置
            int fromIndex = i * groupSize;
            // 结束位置
            int toIndex = (i+1) * groupSize < length ? ( i+1 ) * groupSize : length ;
            newList.add(list.subList(fromIndex,toIndex)) ;
        }
        return  newList ;
    }




    //读取json文件
    public static String readJsonFile(String fileName) {
        String jsonStr = "";
        try {
            File jsonFile = new File(fileName);
            FileReader fileReader = new FileReader(jsonFile);
            Reader reader = new InputStreamReader(new FileInputStream(jsonFile),"utf-8");
            int ch = 0;
            StringBuffer sb = new StringBuffer();
            while ((ch = reader.read()) != -1) {
                sb.append((char) ch);
            }
            fileReader.close();
            reader.close();
            jsonStr = sb.toString();
            return jsonStr;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

}
