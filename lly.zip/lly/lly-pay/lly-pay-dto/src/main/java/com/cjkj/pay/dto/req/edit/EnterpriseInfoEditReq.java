package com.cjkj.pay.dto.req.edit;

import com.cjkj.pay.dto.req.add.EnterpriseInfoAddReq;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
@Data
@ApiModel("企业信息->修改")
public class EnterpriseInfoEditReq extends EnterpriseInfoAddReq {
    @ApiModelProperty("主键")
    @NotBlank(message="未选中数据！")
    private String id;
}