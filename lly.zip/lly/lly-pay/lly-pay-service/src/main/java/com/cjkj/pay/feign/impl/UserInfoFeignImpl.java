package com.cjkj.pay.feign.impl;

import com.alibaba.fastjson.JSONObject;
import com.cjkj.pay.feign.IUserInfoServiceFeign;
import org.springframework.stereotype.Component;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 */
@Component
public class UserInfoFeignImpl implements IUserInfoServiceFeign {

    @Override
    public String getUserInfo(String userId) {
        return "调用user服务超时";
    }

	@Override
	public String getDeptsByNoUserInfo(String menuId) {
		return "调用查询当前登录用户以外的所有机构服务超时";
	}

	@Override
	public String listCompany() {
		return "调用查询所有机构接口服务超时";
	}

	@Override
	public String getUserInfoByUserId(String userId) {
		return "调用根据userId查询登录用户的信息服务超时";
	}

	@Override
	public String getUserInfoAndDept(String userId, String deptId) {
		return "调用获取当前登录用户所属机构以及机构下所有用户信息服务超时";
	}

	@Override
	public String getDeptInfoById(String deptId) {
		return "调用根据deptId和token查询组织机构信息服务超时";
	}

    @Override
    public String getTopDeptId(String userId) {
        return "调用获取当前登录用户的顶级部门服务超时";
    }

    @Override
    public String getAllRoleDeptId(String userId) {
        return "调用获取拥有权限的部门ID列表服务超时";
    }

	@Override
	public JSONObject queryCompanyByRoleId(String roleId) {
		return  JSONObject.parseObject("调用获取当前角色对应机构的机构Id服务超时");
	}

	@Override
	public JSONObject getLoginUserByName(String userName) {
		return JSONObject.parseObject("根据用户姓名查询用户信息接口访问超时");
	}
}
