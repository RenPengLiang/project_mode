package com.cjkj.pay.feign;

import com.cjkj.common.model.ResultData;
import com.cjkj.pay.dto.req.BaseIds;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @author Renpl
 */
@FeignClient(name = "lly-base-api")
public interface IBaseService {

    @PostMapping("/lly/base/base/delete")
    ResultData delete(@RequestBody BaseIds baseIds);
}
