package com.cjkj.pay.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
@Data
@TableName("enterprise_info")
public class EnterpriseInfo implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * 主键
     */
    @TableId(type = IdType.ID_WORKER_STR)
    private String id;

    /**
     * 维修厂机构ID
     */
    private String departmentId;

    /**
     * 名称
     */
    private String name;

    /**
     * 企业类型（1：维修厂，2：承运商）
     */
    private String enterpriseType;

    /**
     * 联系人
     */
    private String contacts;

    /**
     * 联系电话
     */
    private String contactsTel;

    /**
     * 法人
     */
    private String legalPerson;

    /**
     * 营业执照号
     */
    private String businessLicense;

    /**
     * 省
     */
    private String province;

    /**
     * 省
     */
    private String provinceName;

    /**
     * 市
     */
    private String cityName;

    /**
     * 市
     */
    private String city;

    /**
     * 县
     */
    private String county;

    /**
     * 详细地址
     */
    private String address;

    /**
     * 经度
     */
    private BigDecimal lng;

    /**
     * 纬度
     */
    private BigDecimal lat;

    /**
     * 是否有效
     */
    private String effective;

    /**
     * 创建人
     */
    private String createdBy;

    /**
     * 创建人名称
     */
    private String createdByName;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    /**
     * 更新人
     */
    private String updatedBy;

    /**
     * 更新人名称
     */
    private String updatedByName;

    /**
     * 更新时间
     */
    @TableField(fill = FieldFill.UPDATE)
    private Date updateTime;

    /**
     * 开户行
     */
    private String bank;

    /**
     * 开户行账号
     */
    private String bankNo;

    /**
     * 坐标系
     */
    private String coordinate;
}