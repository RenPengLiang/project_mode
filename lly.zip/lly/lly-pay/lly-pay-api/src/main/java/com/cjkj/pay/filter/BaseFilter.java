package com.cjkj.pay.filter;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cjkj.log.monitor.LogUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
@Component
public class BaseFilter implements Filter {

//    @Resource
//    private IUserInfoServiceFeign userInfoServiceFeign;
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        LogUtil.bizInfo("BaseFilter init");
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        String contentType = request.getContentType();
        String path = request.getRequestURI();
        String userName = request.getHeader("x-user-header");

        LogUtil.bizInfo("======进入拦截器获取username={}", userName);
        if (StringUtils.isNotBlank(userName)) {
//            JSONObject jsonObject = userInfoServiceFeign.getLoginUserByName(userName);
            JSONObject jsonObject = new JSONObject();
            LogUtil.info("调用接口返回参数" + JSON.toJSONString(jsonObject));
            Map<String, Object> map = new HashMap<>(10);
            map.put("operUserId", jsonObject.getString("userId"));
            // 姓名
            map.put("operUserName", jsonObject.getString("name"));
            // 登录名
            map.put("loginName", userName);
            if (MediaType.APPLICATION_JSON_VALUE.equals(contentType)
                    || MediaType.APPLICATION_JSON_UTF8_VALUE.equals(contentType)) {
                if (map != null && map.size() > 0) {
                    ParameterRequestWrapper requestWrapper = new ParameterRequestWrapper(request, map);
                    request = requestWrapper;
                }
            }
        }
        filterChain.doFilter(request, servletResponse);
    }

    @Override
    public void destroy() {
        LogUtil.info("BaseFilter destory");
    }
}
